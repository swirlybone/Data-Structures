package Assign2;


public class SearchMethods {
    public static <T extends Comparable<T>> int linearSearch(T[] data, int min, int max, T target) {
        //checking info at index [min] to see if it matches target, if it is it returns index
        if(min == data.length){
            return -1;
        }
        if(data[min].compareTo(target) == 0){
           return min;
        }
        //recursively calls itself with a new index, min goes up by 1. called again and again til it reaches the end of the array
        return linearSearch(data, min++, max, target);
    }

    public static <T extends Comparable<T>> int binarySearch(T[] data, int min, int max, T target) {
        return 0;
    }



}
